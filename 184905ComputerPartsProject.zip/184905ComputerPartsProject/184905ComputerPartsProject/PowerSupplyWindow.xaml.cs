﻿/* Austin McKee
 * Feb 26, 2019
 * This program opens supplier's website, reasons to purchase and a closing button
 */
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _184905ComputerPartsProject
{
    /// <summary>
    /// Interaction logic for PowerSupplyWindow.xaml
    /// </summary>
    public partial class PowerSupplyWindow : Window
    {
        public PowerSupplyWindow()
        {
            InitializeComponent();
        }

        private void ClosingButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void ExplanationButton_Click(object sender, RoutedEventArgs e)
        {
            //ExplanationButton.Content = 
            MessageBox.Show("The Case for a computer holds all the components in place. It holds the Motherboard, Optical Drive and Disk Drive. This Case was the 'Quiet' model, meaning you won't have to worry about unnecessary noise. It also is a big case, so there is more room in case of future expansions to the hardware. It also makes for easy access to the components if something needs to be replaced. It has two front USB ports and two audio ports.");
            MessageBox.Show("The Power Supply does exactly what it's name says. It provides power for the whole computer. It takes power from the outlet and splits it to each individual component. This Power supply was a bigger choice, simply because the Graphics Card will require a large amount of power because it is a more expensive, better Graphics Card. Most components don't need a large amount of power, just the Graphics Card and an Magnetic Arm type Disk Drive.");
        }

        private void CaseImage_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.newegg.ca/Product/Product.aspx?Item=9SIA7RD2WX2993&ignorebbr=1");
        }

        private void PowerSupplyImage_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.newegg.ca/Product/Product.aspx?Item=N82E16817438136&ignorebbr=1");
        }
    }
}
